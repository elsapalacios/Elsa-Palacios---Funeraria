-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 10-05-2025 a las 00:13:19
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `database_funeraria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `afiliacion`
--

CREATE TABLE `afiliacion` (
  `id_afiliacion` int(11) NOT NULL,
  `Id_cedula` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `fecha_registro` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE `compra` (
  `id_compra` int(11) NOT NULL,
  `id_afiliacion` int(11) DEFAULT NULL,
  `fecha` datetime DEFAULT current_timestamp(),
  `descripcion` text DEFAULT NULL,
  `tipo` enum('Rosa','Ataúd','Cartel','Otro') DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_usuario`
--

CREATE TABLE `estado_usuario` (
  `Id_estado_usuario` int(50) NOT NULL,
  `Id_cedula` int(11) NOT NULL,
  `estado_usuario` enum('Vivo','Muerto') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `logs`
--

CREATE TABLE `logs` (
  `id_logs` bigint(20) NOT NULL,
  `Id_cedula` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `direccion_ip` varchar(45) NOT NULL,
  `evento` varchar(50) NOT NULL,
  `detalles` text DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plan`
--

CREATE TABLE `plan` (
  `id_plan` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `cobertura_km` int(11) DEFAULT NULL,
  `tarjetas_agradecimiento` int(11) DEFAULT NULL,
  `tipo_cofre` varchar(50) DEFAULT NULL,
  `incluye_lapida` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `plan_servicio`
--

CREATE TABLE `plan_servicio` (
  `id_plan` int(11) NOT NULL,
  `id_servicio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `id_servicio` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `tipo` enum('Acompañamiento','Elementos Fúnebres','Transporte','Cafetería','Misa','Otros') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_afiliacion`
--

CREATE TABLE `tipo_afiliacion` (
  `id_tipo` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `Id_cedula` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `usuario` int(50) NOT NULL,
  `contraseña_hash` varchar(255) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `telefono` int(100) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `tipo_afiliacion` enum('Contribuyente','Beneficiario') DEFAULT NULL,
  `rol` enum('Admin','Empleado','Cliente') NOT NULL,
  `intentos_fallidos` tinyint(4) DEFAULT 0,
  `bloqueado` tinyint(1) DEFAULT 0,
  `fecha_bloqueo` datetime DEFAULT NULL,
  `ultimo_login` datetime DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `afiliacion`
--
ALTER TABLE `afiliacion`
  ADD PRIMARY KEY (`id_afiliacion`),
  ADD KEY `Id_cedula` (`Id_cedula`),
  ADD KEY `id_tipo` (`id_tipo`);

--
-- Indices de la tabla `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`id_compra`),
  ADD KEY `id_afiliacion` (`id_afiliacion`);

--
-- Indices de la tabla `estado_usuario`
--
ALTER TABLE `estado_usuario`
  ADD PRIMARY KEY (`Id_estado_usuario`),
  ADD KEY `Id_usuario` (`Id_cedula`);

--
-- Indices de la tabla `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id_logs`),
  ADD KEY `idx_fecha` (`fecha`);

--
-- Indices de la tabla `plan`
--
ALTER TABLE `plan`
  ADD PRIMARY KEY (`id_plan`);

--
-- Indices de la tabla `plan_servicio`
--
ALTER TABLE `plan_servicio`
  ADD PRIMARY KEY (`id_plan`,`id_servicio`),
  ADD KEY `id_servicio` (`id_servicio`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD PRIMARY KEY (`id_servicio`);

--
-- Indices de la tabla `tipo_afiliacion`
--
ALTER TABLE `tipo_afiliacion`
  ADD PRIMARY KEY (`id_tipo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`Id_cedula`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `afiliacion`
--
ALTER TABLE `afiliacion`
  MODIFY `id_afiliacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `compra`
--
ALTER TABLE `compra`
  MODIFY `id_compra` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `estado_usuario`
--
ALTER TABLE `estado_usuario`
  MODIFY `Id_estado_usuario` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `logs`
--
ALTER TABLE `logs`
  MODIFY `id_logs` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `plan`
--
ALTER TABLE `plan`
  MODIFY `id_plan` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `servicio`
--
ALTER TABLE `servicio`
  MODIFY `id_servicio` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipo_afiliacion`
--
ALTER TABLE `tipo_afiliacion`
  MODIFY `id_tipo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `Id_cedula` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `afiliacion`
--
ALTER TABLE `afiliacion`
  ADD CONSTRAINT `afiliacion_ibfk_1` FOREIGN KEY (`Id_cedula`) REFERENCES `usuarios` (`Id_cedula`),
  ADD CONSTRAINT `afiliacion_ibfk_2` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_afiliacion` (`id_tipo`);

--
-- Filtros para la tabla `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `compra_ibfk_1` FOREIGN KEY (`id_afiliacion`) REFERENCES `afiliacion` (`id_afiliacion`);

--
-- Filtros para la tabla `estado_usuario`
--
ALTER TABLE `estado_usuario`
  ADD CONSTRAINT `estado_usuario_ibfk_1` FOREIGN KEY (`Id_cedula`) REFERENCES `estado_usuario` (`Id_estado_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `plan_servicio`
--
ALTER TABLE `plan_servicio`
  ADD CONSTRAINT `plan_servicio_ibfk_1` FOREIGN KEY (`id_plan`) REFERENCES `plan` (`id_plan`),
  ADD CONSTRAINT `plan_servicio_ibfk_2` FOREIGN KEY (`id_servicio`) REFERENCES `servicio` (`id_servicio`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;



-- --------------------------------------------------------
-- Tabla de Bloqueo de Usuario
CREATE TABLE `bloqueo_usuario` (
  `id_bloqueo` INT AUTO_INCREMENT PRIMARY KEY,
  `Id_cedula` INT NOT NULL,
  `motivo` TEXT,
  `fecha_bloqueo` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`Id_cedula`) REFERENCES afiliacion(`Id_cedula`)
);

-- --------------------------------------------------------
-- Tabla de Tipo de Afiliación
CREATE TABLE `tipo_afiliacion` (
  `id_tipo` INT PRIMARY KEY,
  `nombre_tipo` ENUM('Contribuyente', 'Beneficiario') NOT NULL
);

-- Agregar FK a afiliacion
ALTER TABLE `afiliacion`
ADD CONSTRAINT fk_tipo_afiliacion
FOREIGN KEY (`id_tipo`) REFERENCES tipo_afiliacion(`id_tipo`);

-- --------------------------------------------------------
-- Tabla de Servicio de Acompañamiento
CREATE TABLE `servicio_acompanamiento` (
  `id_servicio` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre_servicio` ENUM('Silla', 'Elementos Fúnebres') NOT NULL,
  `id_afiliacion` INT,
  `fecha_servicio` DATE,
  FOREIGN KEY (`id_afiliacion`) REFERENCES afiliacion(`id_afiliacion`)
);



-- Tabla de bloqueo de usuario
CREATE TABLE `bloqueo_usuario` (
  `id_bloqueo` INT AUTO_INCREMENT PRIMARY KEY,
  `Id_cedula` INT NOT NULL,
  `motivo` VARCHAR(255),
  `fecha_bloqueo` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `estado` ENUM('Activo', 'Levantado') DEFAULT 'Activo',
  FOREIGN KEY (`Id_cedula`) REFERENCES `estado_usuario`(`Id_cedula`)
);

-- Tabla de logs (redefinida con evento y fecha)
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id_logs` BIGINT AUTO_INCREMENT PRIMARY KEY,
  `Id_cedula` INT NOT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  `direccion_ip` VARCHAR(45) NOT NULL,
  `evento` TEXT NOT NULL,
  `fecha_evento` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`Id_cedula`) REFERENCES `estado_usuario`(`Id_cedula`)
);

-- Tabla de servicios
CREATE TABLE `servicios` (
  `id_servicio` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre_servicio` VARCHAR(100) NOT NULL,
  `descripcion` TEXT
);

-- Tabla intermedia afiliado - servicio
CREATE TABLE `afiliado_servicio` (
  `id_afiliado_servicio` INT AUTO_INCREMENT PRIMARY KEY,
  `id_afiliacion` INT NOT NULL,
  `id_servicio` INT NOT NULL,
  `fecha_servicio` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`id_afiliacion`) REFERENCES `afiliacion`(`id_afiliacion`),
  FOREIGN KEY (`id_servicio`) REFERENCES `servicios`(`id_servicio`)
);

-- Tabla de tipo de afiliación
CREATE TABLE `tipo_afiliacion` (
  `id_tipo` INT AUTO_INCREMENT PRIMARY KEY,
  `nombre_tipo` ENUM('Contribuyente', 'Beneficiario') NOT NULL
);

-- Enlace tipo_afiliacion con afiliacion
ALTER TABLE `afiliacion`
ADD CONSTRAINT `fk_tipo_afiliacion`
FOREIGN KEY (`id_tipo`) REFERENCES `tipo_afiliacion`(`id_tipo`);

-- Inserción de ejemplos en servicios
INSERT INTO `servicios` (nombre_servicio, descripcion) VALUES
('Acompañamiento con sillas', 'Sillas para acompañantes en velación'),
('Elementos fúnebres', 'Velas, mantos, arreglos'),
('Transporte fúnebre', 'Carroza para traslado');



-- ===========================================
-- FUNCIONES
-- ===========================================

-- Función: Obtener el nombre completo del afiliado por su ID
DELIMITER //
CREATE FUNCTION obtener_nombre_afiliado(ced INT) RETURNS VARCHAR(200)
DETERMINISTIC
BEGIN
  DECLARE nombre_completo VARCHAR(200);
  SELECT CONCAT_WS(' ', nombres, apellidos) INTO nombre_completo
  FROM estado_usuario
  WHERE Id_cedula = ced;
  RETURN nombre_completo;
END;
//
DELIMITER ;

-- ===========================================
-- TRIGGERS
-- ===========================================

-- Trigger: Insertar log automáticamente al registrar un nuevo usuario
DELIMITER //
CREATE TRIGGER trg_log_registro_usuario
AFTER INSERT ON estado_usuario
FOR EACH ROW
BEGIN
  INSERT INTO logs (Id_cedula, nombre, direccion_ip, evento)
  VALUES (NEW.id_cedula, CONCAT_WS(' ', NEW.nombres, NEW.apellidos), '127.0.0.1', 'Registro de nuevo usuario');
END;
//
DELIMITER ;

-- Trigger: Registrar servicio solicitado por afiliado
DELIMITER //
CREATE TRIGGER trg_log_servicio_solicitado
AFTER INSERT ON afiliado_servicio
FOR EACH ROW
BEGIN
  INSERT INTO logs (Id_cedula, nombre, direccion_ip, evento)
  SELECT a.Id_cedula, CONCAT_WS(' ', e.nombres, e.apellidos), '127.0.0.1',
         CONCAT('Servicio solicitado: ', s.nombre_servicio)
  FROM afiliacion a
  JOIN estado_usuario e ON a.Id_cedula = e.Id_cedula
  JOIN servicios s ON NEW.id_servicio = s.id_servicio
  WHERE a.id_afiliacion = NEW.id_afiliacion;
END;
//
DELIMITER ;

-- ===========================================
-- PROCEDIMIENTOS ALMACENADOS
-- ===========================================

-- Procedimiento: Bloquear usuario
DELIMITER //
CREATE PROCEDURE bloquear_usuario(IN ced INT, IN razon VARCHAR(255))
BEGIN
  INSERT INTO bloqueo_usuario (Id_cedula, motivo, estado)
  VALUES (ced, razon, 'Activo');
END;
//
DELIMITER ;

-- Procedimiento: Registrar afiliación con tipo
DELIMITER //
CREATE PROCEDURE registrar_afiliacion(IN ced INT, IN id_tipo INT)
BEGIN
  INSERT INTO afiliacion (Id_cedula, id_tipo)
  VALUES (ced, id_tipo);
END;
//
DELIMITER ;

-- ===========================================
-- VISTAS
-- ===========================================

-- Vista: Listado de afiliados vivos o muertos
CREATE OR REPLACE VIEW vista_estado_afiliados AS
SELECT u.Id_cedula, u.nombres, u.apellidos, u.estado
FROM estado_usuario u;

-- Vista: Registro de servicios por afiliado
CREATE OR REPLACE VIEW vista_servicios_por_afiliado AS
SELECT a.id_afiliacion, e.nombres, e.apellidos, s.nombre_servicio, afs.fecha_servicio
FROM afiliado_servicio afs
JOIN afiliacion a ON afs.id_afiliacion = a.id_afiliacion
JOIN estado_usuario e ON a.Id_cedula = e.Id_cedula
JOIN servicios s ON afs.id_servicio = s.id_servicio;
