<?php
// conexión
$conexion = new mysqli("localhost", "root", "", "funeraria_optimizada");
if ($conexion->connect_error) {
  die("Conexión fallida: " . $conexion->connect_error);
}

// capturar datos
$nombre = $_POST['nombre'];
$apellidos = $_POST['apellidos'];
$documento = $_POST['documento'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$direccion = $_POST['direccion'];

// insertar
$sql = "INSERT INTO usuarios (nombre, apellidos, documento, correo, telefono, direccion, fecha_registro)
        VALUES ('$nombre', '$apellidos', '$documento', '$correo', '$telefono', '$direccion', CURDATE())";

if ($conexion->query($sql) === TRUE) {
  echo "Registro exitoso.";
} else {
  echo "Error: " . $sql . "<br>" . $conexion->error;
}

$conexion->close();
?>
