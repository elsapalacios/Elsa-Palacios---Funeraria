<?php
$host = "localhost"; // o el nombre del servidor
$usuario = "root";   // tu usuario de MySQL
$contrasena = "";    // tu contraseña
$base_datos = "funeraria_optimizada"; // nombre de tu base de datos

$conn = new mysqli($host, $usuario, $contrasena, $base_datos);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Establecer codificación
$conn->set_charset("utf8");
?>
